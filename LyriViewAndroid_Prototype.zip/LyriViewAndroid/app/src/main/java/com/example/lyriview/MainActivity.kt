package com.example.lyriview

import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.FolderOpen
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.PlayerView
import kotlinx.coroutines.delay

private val Neon = Color(0xFFD6FF00)
private val Dark = Color(0xFF08090B)

data class LyricLine(val timeMs: Long, val text: String)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { LyriViewApp() }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LyriViewApp() {
    val context = androidx.compose.ui.platform.LocalContext.current
    var videoUri by remember { mutableStateOf<Uri?>(null) }
    var lyricName by remember { mutableStateOf("No lyrics loaded") }
    var rawLyrics by remember { mutableStateOf<List<LyricLine>>(emptyList()) }
    var plainLyrics by remember { mutableStateOf("") }
    var currentPosition by remember { mutableLongStateOf(0L) }
    var isPlaying by remember { mutableStateOf(false) }
    var message by remember { mutableStateOf("Choose a local video and import lyrics") }

    val exoPlayer = remember {
        ExoPlayer.Builder(context).build().apply {
            repeatMode = Player.REPEAT_MODE_OFF
            addListener(object : Player.Listener {
                override fun onIsPlayingChanged(playing: Boolean) { isPlaying = playing }
            })
        }
    }

    DisposableEffect(Unit) { onDispose { exoPlayer.release() } }

    val videoPicker = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri != null) {
            videoUri = uri
            runCatching { context.contentResolver.takePersistableUriPermission(uri, android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION) }
            exoPlayer.setMediaItem(MediaItem.fromUri(uri))
            exoPlayer.prepare()
            exoPlayer.playWhenReady = true
            message = "Video ready"
        }
    }

    val lyricPicker = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri != null) {
            runCatching { context.contentResolver.takePersistableUriPermission(uri, android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION) }
            val text = runCatching {
                context.contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() }
            }.getOrNull().orEmpty()
            val name = uri.lastPathSegment?.substringAfterLast('/') ?: "Imported lyrics"
            lyricName = name
            val parsed = parseLrc(text)
            if (parsed.isNotEmpty()) {
                rawLyrics = parsed
                plainLyrics = ""
                message = "Timed lyrics loaded"
            } else {
                rawLyrics = emptyList()
                plainLyrics = text
                message = if (text.isBlank()) "Could not read that file" else "Text lyrics loaded (not timed)"
            }
        }
    }

    LaunchedEffect(exoPlayer) {
        while (true) {
            currentPosition = exoPlayer.currentPosition.coerceAtLeast(0L)
            delay(120)
        }
    }

    val activeIndex = rawLyrics.indexOfLast { it.timeMs <= currentPosition }
    val activeLine = if (activeIndex >= 0) rawLyrics[activeIndex].text else "♪"
    val nextLine = rawLyrics.getOrNull(activeIndex + 1)?.text.orEmpty()
    val previousLine = rawLyrics.getOrNull(activeIndex - 1)?.text.orEmpty()

    MaterialTheme(colorScheme = darkColorScheme(
        primary = Neon, onPrimary = Color.Black, background = Dark, surface = Color(0xFF141518),
        onBackground = Color.White, onSurface = Color.White
    )) {
        Scaffold(containerColor = Dark) { padding ->
            Column(Modifier.fillMaxSize().padding(padding).background(Dark)) {
                Row(
                    Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 12.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column {
                        Text("LYRIVIEW", color = Neon, fontWeight = FontWeight.Black, fontSize = 22.sp, letterSpacing = 2.sp)
                        Text("VIDEOS • WORDS • VIBE", color = Color.LightGray, fontSize = 10.sp, letterSpacing = 1.5.sp)
                    }
                    Text("LOCAL PLAYER", color = Color.Gray, fontSize = 10.sp)
                }

                Box(
                    Modifier.weight(1f).fillMaxWidth().padding(horizontal = 12.dp)
                        .background(Color(0xFF17191D), RoundedCornerShape(22.dp))
                ) {
                    if (videoUri != null) {
                        AndroidView(
                            modifier = Modifier.fillMaxSize(),
                            factory = { ctx ->
                                PlayerView(ctx).apply {
                                    player = exoPlayer
                                    useController = true
                                    resizeMode = AspectRatioFrameLayout.RESIZE_MODE_ZOOM
                                    setShowBuffering(PlayerView.SHOW_BUFFERING_WHEN_PLAYING)
                                }
                            },
                            update = { it.player = exoPlayer }
                        )
                        Box(
                            Modifier.fillMaxSize().background(
                                Brush.verticalGradient(
                                    colors = listOf(Color.Transparent, Color.Transparent, Color(0xCC000000)),
                                    startY = 0f
                                )
                            )
                        )
                        Column(
                            Modifier.align(Alignment.Center).fillMaxWidth().padding(horizontal = 18.dp),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.Center
                        ) {
                            if (previousLine.isNotBlank()) {
                                Text(previousLine, color = Color.White.copy(alpha = .55f), fontSize = 16.sp,
                                    textAlign = TextAlign.Center, maxLines = 2)
                                Spacer(Modifier.height(12.dp))
                            }
                            Text(
                                activeLine,
                                color = Neon,
                                fontSize = 29.sp,
                                lineHeight = 35.sp,
                                fontWeight = FontWeight.ExtraBold,
                                textAlign = TextAlign.Center
                            )
                            if (nextLine.isNotBlank()) {
                                Spacer(Modifier.height(12.dp))
                                Text(nextLine, color = Color.White.copy(alpha = .75f), fontSize = 17.sp,
                                    textAlign = TextAlign.Center, maxLines = 2)
                            }
                        }
                        Text(
                            lyricName,
                            Modifier.align(Alignment.BottomStart).padding(14.dp)
                                .background(Color.Black.copy(alpha = .55f), RoundedCornerShape(8.dp)).padding(8.dp),
                            color = Color.White, fontSize = 11.sp, maxLines = 1
                        )
                    } else {
                        Column(
                            Modifier.align(Alignment.Center).padding(28.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Icon(Icons.Default.MusicNote, null, tint = Neon, modifier = Modifier.size(64.dp))
                            Spacer(Modifier.height(12.dp))
                            Text("Your video. Your lyrics.", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center)
                            Spacer(Modifier.height(8.dp))
                            Text("Load a video from your phone to start.", color = Color.LightGray, textAlign = TextAlign.Center)
                        }
                    }
                }

                Text(message, Modifier.fillMaxWidth().padding(top = 10.dp, start = 18.dp, end = 18.dp),
                    color = Color.LightGray, fontSize = 12.sp, textAlign = TextAlign.Center)

                Row(
                    Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 10.dp),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Button(
                        onClick = { videoPicker.launch(arrayOf("video/*")) },
                        modifier = Modifier.weight(1f),
                        colors = ButtonDefaults.buttonColors(containerColor = Neon, contentColor = Color.Black),
                        shape = RoundedCornerShape(14.dp)
                    ) {
                        Icon(Icons.Default.FolderOpen, null)
                        Spacer(Modifier.width(6.dp))
                        Text("Open video", fontWeight = FontWeight.Bold)
                    }
                    OutlinedButton(
                        onClick = { lyricPicker.launch(arrayOf("text/*", "application/octet-stream", "*/*")) },
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(14.dp),
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = Color.White)
                    ) {
                        Icon(Icons.Default.MusicNote, null)
                        Spacer(Modifier.width(6.dp))
                        Text("Import lyrics")
                    }
                }

                if (plainLyrics.isNotBlank()) {
                    Text("LOCAL LYRICS", color = Neon, fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(start = 18.dp, end = 18.dp, top = 2.dp, bottom = 4.dp), fontSize = 12.sp)
                    LazyColumn(
                        Modifier.fillMaxWidth().heightIn(max = 130.dp).padding(horizontal = 18.dp, vertical = 4.dp)
                    ) {
                        itemsIndexed(plainLyrics.lines().filter { it.isNotBlank() }) { _, line ->
                            Text(line, color = Color.White, modifier = Modifier.padding(vertical = 3.dp), fontSize = 14.sp)
                        }
                    }
                } else if (rawLyrics.isNotEmpty()) {
                    Text("${rawLyrics.size} timed lines • ${(currentPosition / 1000)} sec",
                        color = Color.Gray, fontSize = 11.sp,
                        modifier = Modifier.padding(start = 18.dp, bottom = 10.dp))
                } else {
                    Spacer(Modifier.height(6.dp))
                }
            }
        }
    }
}

private fun parseLrc(source: String): List<LyricLine> {
    val regex = Regex("""\[(\d{1,2}):(\d{2})(?:[.:](\d{1,3}))?]""")
    val result = mutableListOf<LyricLine>()
    source.lineSequence().forEach { line ->
        val matches = regex.findAll(line).toList()
        if (matches.isNotEmpty()) {
            val lyricText = line.substringAfterLast("]").trim().ifBlank { return@forEach }
            matches.forEach { match ->
                val minutes = match.groupValues[1].toLongOrNull() ?: 0L
                val seconds = match.groupValues[2].toLongOrNull() ?: 0L
                val fractionRaw = match.groupValues[3]
                val fractionMs = when (fractionRaw.length) {
                    1 -> (fractionRaw.toLongOrNull() ?: 0L) * 100L
                    2 -> (fractionRaw.toLongOrNull() ?: 0L) * 10L
                    3 -> fractionRaw.toLongOrNull() ?: 0L
                    else -> 0L
                }
                result += LyricLine((minutes * 60 + seconds) * 1000 + fractionMs, lyricText)
            }
        }
    }
    return result.sortedBy { it.timeMs }
}
