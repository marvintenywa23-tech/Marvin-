# LyriView Android prototype

LyriView is a starter Android app for vertical local music videos with large centered lyrics.

## Current prototype features
- Open and play a video stored on the Android device.
- Import a local `.lrc` timed lyrics file and highlight the active lyric line based on playback time.
- Import a `.txt` file and show its lyrics below the video.
- Dark, vertical-video-first interface with neon lyric text.
- Uses Android's document picker, so the app does not need broad storage permission.

## Requirements
- Android Studio (recent version)
- JDK 17
- Android SDK 35

## Run it
1. Unzip the project.
2. Open the `LyriViewAndroid` folder in Android Studio.
3. Let Gradle sync and install any requested SDK components.
4. Connect an Android phone with USB debugging enabled, or start an emulator.
5. Press **Run**.

The first build needs internet access to download Gradle dependencies.

## How to use
1. Tap **Open video** and choose a local video.
2. Tap **Import lyrics** and choose a `.lrc` or `.txt` file.
3. For synchronized lyrics, use an LRC file with timestamps, for example:

```lrc
[00:00.00]First line of the song
[00:04.50]Second line of the song
[00:08.20]Third line of the song
```

## Important limitations of this starter
- This is source code for a prototype, not a signed APK.
- The current prototype does not yet remember a complete library of previously imported items after the app is closed.
- Lyrics timing depends on the accuracy of the LRC file. TXT lyrics are not automatically synchronized.
- Use video and lyric files you own or have permission to use. The prototype plays local videos and does not download or redistribute copyrighted content.
- The video player controls are provided by Android Media3. A later version can add a custom TikTok-like timeline, playlists, saved lyric library, subtitle styling, and audio/video synchronization tools.


## Build an APK without owning a computer (cloud build)
This project includes `.github/workflows/android-apk.yml` for a cloud build on GitHub Actions.
From your phone:
1. Create/sign in to a GitHub account and create a new repository.
2. Upload the extracted project files to the repository, keeping the `.github/workflows/android-apk.yml` path.
3. Open the repository's **Actions** tab and select **Build LyriView APK**. If needed, tap **Run workflow**.
4. When the workflow completes successfully, open that run and download the **LyriView-debug-apk** artifact.
5. Extract the downloaded artifact ZIP on your phone and tap `app-debug.apk` to install it. Android may ask you to allow installs from that browser/file manager.

The APK from this workflow is a debug build for testing, not a Play Store release. Cloud building requires a GitHub account and internet access.
